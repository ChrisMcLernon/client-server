import socket
import struct
import logging
import threading

# Using a dictionary for operations makes it easy to add new operations in the future.
operations = {
    b'+': lambda x, y: x + y,
    b'-': lambda x, y: x - y,
    b'*': lambda x, y: x * y,
    b'/': lambda x, y: x / y if y != 0 else float('inf'),  # Handle division by zero
}

def perform_operation(operation, operand1, operand2):
    """
    Performs a mathematical operation based on the given operation and operands.

    Args:
    operation (bytes): The operation to perform (+, -, *, /).
    operand1 (float): The first operand.
    operand2 (float): The second operand.

    Returns:
    float: Result of the operation.

    Raises:
    ValueError: If the operation is unsupported.
    """
    if operation in operations:
        return operations[operation](operand1, operand2)
    else:
        raise ValueError("Unsupported operation")

def handle_client(conn, addr):
    """
    Handles a client connection, performing requested operations and sending results.

    Args:
    conn (socket): The client connection socket.
    addr (tuple): Address of the client.
    """
    logging.info(f"Connected by {addr}")
    try:
        data = conn.recv(17)  # Adjusted to receive 17 bytes for two floats and an operation
        if len(data) == 17:
            operation, operand1, operand2 = struct.unpack('!cdd', data)
            try:
                result = perform_operation(operation, operand1, operand2)
                conn.sendall(struct.pack('!d', result))
            except ValueError as e:
                conn.sendall(struct.pack('!d', float('nan')))
                logging.error(f"Error: {e}")
        logging.info(f"Connection closed with {addr}")
    finally:
        conn.close()

def start_server():
    """
    Starts a TCP server that performs arithmetic operations based on client requests.
    """
    logging.basicConfig(level=logging.INFO)
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('localhost', 12345))
    server_socket.listen(5)  # Allow up to 5 queued connections
    logging.info("Server is listening on port 12345")

    while True:
        conn, addr = server_socket.accept()
        threading.Thread(target=handle_client, args=(conn, addr)).start()

if __name__ == "__main__":
    start_server()