import socket
import struct

def send_operation(operation, operand1, operand2):
    """
    Sends an arithmetic operation to a server, receives the result, and returns it.

    Args:
    operation (str): The operation to perform ('+', '-', '*', '/', '!' to exit).
    operand1 (float): The first operand for the operation.
    operand2 (float): The second operand for the operation.

    Returns:
    float or None: Result of the operation if successful, None if '!' is sent to exit.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        client_socket.connect(('localhost', 12345))
        if operation == '!':
            client_socket.sendall(b'!')
            return None
        
        packed_data = struct.pack('!cdd', operation.encode(), operand1, operand2)
        client_socket.sendall(packed_data)
        result_data = client_socket.recv(8)  # Adjusted to receive 8 bytes for a float result
        result = struct.unpack('!d', result_data)[0]
        return result

if __name__ == "__main__":
    while True:
        operation = input("Enter operation (+, -, *, /, ! to exit): ").strip()
        if operation == '!':
            send_operation('!', 0, 0)
            print("Exiting...")
            break
        
        if operation not in ['+', '-', '*', '/']:
            print("Unsupported operation.")
            continue
        
        try:
            operand1 = float(input("Enter first operand: "))
            operand2 = float(input("Enter second operand: "))
        except ValueError:
            print("Operands must be numbers.")
            continue
        
        result = send_operation(operation, operand1, operand2)
        if result is not None:
            print(f"The result is: {result}")